
// func viewHandler(w http.ResponseWriter, r *http.Request, title string) {

//     p, err := loadPage(title)
//     if err != nil {
//         http.Redirect(w, r, "/edit/"+title, http.StatusFound)
//         return
//     }

//     renderTemplate(w, "view", p);
// }

// func editHandler(w http.ResponseWriter, r *http.Request, title string) {
//     p, err := loadPage(title)
//     if err != nil {
//         p = &Page{Title: title}
//     }
//     renderTemplate(w, "edit", p);
// }

// func saveHandler(w http.ResponseWriter, r *http.Request, title string) {

//     body := r.FormValue("body")
//     p := &Page{Title: title, Body: []byte(body)}
//     err := p.save()
//     if err != nil {
//         http.Error(w, err.Error(), http.StatusInternalServerError)
//         return
//     }
//     http.Redirect(w, r, "/view/"+title, http.StatusFound)
// }



// // Load templates on program initialisation
// func initLol() {
//     if templates == nil {
//         templates = make(map[string]*template.Template)
//     }

//     // templatesDir := config.Templates.Path
//     templatesDir := "core/views/"

//     layouts, err := filepath.Glob(templatesDir + "layouts/*.tmpl")
//     if err != nil {
//         log.Fatal(err)
//     }

//     includes, err := filepath.Glob(templatesDir + "includes/*.tmpl")
//     if err != nil {
//         log.Fatal(err)
//     }

//     // Generate our templates map from our layouts/ and includes/ directories
//     for _, layout := range layouts {
//         files := append(includes, layout)
//         templates[filepath.Base(files[0])] = template.Must(template.ParseFiles(files...))
//     }


// }



// func getTitle(w http.ResponseWriter, r *http.Request) (string, error) {
//     m := validPath.FindStringSubmatch(r.URL.Path)
//     if m == nil {
//         http.NotFound(w, r)
//         return "", errors.New("Invalid Page Title")
//     }
//     return m[2], nil // The title is the second subexpression.
// }

// var validPath = regexp.MustCompile("^/(edit|save|view|admin)/([a-zA-Z0-9]+)$")

// func makeHandler(fn func(http.ResponseWriter, *http.Request, string)) http.HandlerFunc {
//     return func(w http.ResponseWriter, r *http.Request) {
//     	// Here we will extract the page title from the Request,
// 		// and call the provided handler 'fn'
//         m := validPath.FindStringSubmatch(r.URL.Path)
//         if m == nil {
//             http.NotFound(w, r)
//             return
//         }
//         fn(w, r, m[2])
//     }
// }