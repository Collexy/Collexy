var mediaTypeControllers = angular.module('mediaTypeControllers', []);

mediaTypeControllers.controller('MediaTypeTreeCtrl', ['$scope', '$stateParams', 'NodeChildren','Node', function ($scope, $stateParams, NodeChildren, Node) {

  $scope.delete = function(data) {
    data.nodes = [];
  };
  $scope.expand_collapse = function(data) {
    if(!data.show){
      if(data.nodes == undefined){
        data.nodes = [];
      }
      if(data.nodes.length == 0){
        // REST API call to fetch the current node's immediaTypete children
        data.nodes = NodeChildren.query({ nodeId: data.id}, function(node){
          //console.log(node)
        });

      }
    }
    data.show = !data.show;
  }          
  $scope.add = function(data) {
    var post = data.nodes.length + 1;
    var newName = data.name + '-' + post;
                          data.nodes.push({name: newName, show: true, nodes: []});
  };
  //var mediaTypeNodes = MediaTypeNode.query(function(node){
  var mediaTypeNodes = Node.query({'node-type': '7', 'levels': '1'},{},function(node){
          //console.log(node)
        });

  $scope.tree = mediaTypeNodes;



  $scope.menuOptions = [
      {
        "name": "Create",
        "target": "adminMediaType.create",
        "attr": "href",
        "children": [
          {
            "name": "TextPage",
            "target": "adminMediaType.create",
            "attr": "ui-sref"
          },
          {
            "name": "Product",
            "target": "adminMediaType.create",
            "attr": "ui-sref"
          }
        ]
      },
      {
        "name": "Delete",
        "target": "adminMediaType.delete",
        "attr": "ui-sref"
      }
  ];

  $scope.contextMenu = function(node_type){
    alert(node_type);
  }

  var offset = {
        left: 40,
        top: -80
  }

  var $oLay = angular.element(document.getElementById('overlay'))

  $scope.showOptions = function (item,$event) {       
      var overlayDisplay;

      if ($scope.currentItem === item) {
          $scope.currentItem = null;
           overlayDisplay='none'
      }else{
          $scope.currentItem = item;
          overlayDisplay='block'
      }
    
      var overLayCSS = {
          left: $event.clientX + offset.left + 'px',
          top: $event.clientY + offset.top + 'px',
          display: overlayDisplay
      }

       $oLay.css(overLayCSS)
  }

}]);

